<footer class="py-3 text-bg-info text-center">
    &copy; <script>document.write(new Date().getFullYear())</script> BookingApp, All rights reserved.
</footer>