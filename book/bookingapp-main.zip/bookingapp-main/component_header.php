<div class="container-fluid py-2 bg-white">
    <div class="container">
        <img src="\bookingwebapp\img\logo.png" style="max-width: 120px;" class="mx-auto d-block" alt="ศูนย์ผลิตภัณฑ์การแพทย์ขั้นสูง สถาบันชีววิทยาศาสตร์ทางการแพทย์">
    </div>
</div>