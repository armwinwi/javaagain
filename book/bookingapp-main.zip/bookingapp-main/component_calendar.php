<div class="container" id="contentBox">
    <div class="text-end">
        <p><b>Welcome Anonymous, Please <a href="#" data-bs-toggle="modal" data-bs-target="#userLogin">Login</a> First!</b><br>
        BookingApp System - Version 1.00</p>
    </div>

    <h3 class="text-center mt-4">Scheduling Calendar</h3>
    <hr>

    <div class="container py-3" id='calendar'></div>
</div>